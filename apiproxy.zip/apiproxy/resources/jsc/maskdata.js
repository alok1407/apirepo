//get response body
var xmlText = context.getVariable("response.content");

function replacer(key,value)
{
    if (key=="long_name") return "xxxx";
    
    else if (key=="short_name") return "xxxx";
    else return value;
    
}
var x = JSON.parse(xmlText);

var output = (JSON.stringify(x, replacer));

context.setVariable("output", output);